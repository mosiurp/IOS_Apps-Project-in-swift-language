//
//  ViewController.swift
//  BMI Calculator
//
//  Created by Tasauf Mim on 24/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var weight: Double = 0
    var height: Double = 0
    var BMI:  Double = 0
    var male: Bool = true
    var weightText = ""
    var imageName = ""
    var labelColor: UIColor = UIColor.black

    @IBOutlet weak var weightTextField: UITextField!
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var weightLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func genderSwitch(_ sender: UISwitch) {
        if sender.isOn {
            male = false
        } else {
            male = true
        }
    }
    
    @IBAction func calculateButton(_ sender: Any) {
        
        if weightTextField.text != "" && heightTextField.text != "" {
            weight = Double(weightTextField.text!)!
            height = Double(heightTextField.text!)! * 0.0254
            
            BMI = weight / ( height * height )
            
            if BMI < 18.5 {
                weightText = "Your are in Under Weight"
                labelColor = UIColor.red
                if male == true {
                    imageName = "Male_underWeight"
                } else {
                    imageName = "Female_underWeight"
                }
            } else if BMI > 18.5 && BMI < 25 {
                weightText = "Your are in Perfect Weight"
                labelColor = UIColor.green
                if male == true {
                    imageName = "Male_NormalWeight"
                } else {
                    imageName = "Female_NormalWeight"
                }
            } else if BMI >= 25 && BMI < 30 {
                weightText = "Your are in Over Weight"
                labelColor = UIColor.black
                if male == true {
                    imageName = "Male_OverWeight"
                } else {
                    imageName = "Female_OverWeight"
                }
            } else if BMI >= 30 && BMI < 35 {
                weightText = "Your weight is Obese"
                labelColor = UIColor.red
                if male == true {
                    imageName = "Male_obese"
                } else {
                    imageName = "Female_obese"
                }
            } else {
                weightText = "Your weight is Extreme Obese"
                labelColor = UIColor.red
                if male == true {
                    imageName = "Male_extremeObese"
                } else {
                    imageName = "Female_extremeObese"
                }
            }
            
            weightLabel.text = weightText
            weightLabel.textColor = labelColor
            imageView.image = UIImage(named: imageName)
        } else {
            weightTextField.placeholder = "Your Must Give input"
            heightTextField.placeholder = "Your Must Give input"
            
            weightTextField.backgroundColor = UIColor.lightGray
            heightTextField.backgroundColor = UIColor.lightGray
        }
        
    }
    
}


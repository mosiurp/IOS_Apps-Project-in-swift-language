//
//  DictionaryViewController.swift
//  B2E Voice Dictionary
//
//  Created by Tasauf Mim on 25/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit
import AVFoundation

class DictionaryViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    let dataList = ["আমি ভাত খাই", "আমি স্কুলে যাই", "আমি এক গ্লাস পানি প্রয়োজন",]
    let voiceList = ["I eat rice", "I go to school" , "I need a glass of water"]
    
    var audioPlayer: AVAudioPlayer!
    
    @IBOutlet weak var dataTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dataTableView.delegate = self
        dataTableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "dataCell", for: indexPath)
        
        cell.textLabel?.text = dataList[indexPath.row]
        
        if indexPath.row % 2 == 0 {
            cell.textLabel?.backgroundColor = UIColor.cyan
        }

        return cell
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataList.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let soundURL = Bundle.main.url(forResource: voiceList[indexPath.row], withExtension: "MP3")
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL!)
        } catch {
            print(error)
        }
        audioPlayer.play()
    }
}

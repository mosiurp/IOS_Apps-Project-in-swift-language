//
//  SecondViewController.swift
//  iTask
//
//  Created by Tasauf Mim on 9/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var inputField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func addButton (_ sender: Any) {
        allTask.append(inputField.text!)
        inputField.text = ""
    }

}


//
//  ViewController.swift
//  iCalculator
//
//  Created by Tasauf Mim on 19/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var displayText: String = ""
    var preNumber: Double = 0
    var postNumber: Double = 0
    var result: Double = 0
    var pointCounter = 0
    
    var plusPressed: Bool = false
    var minusPressed: Bool = false
    var multiplierPressed: Bool = false
    var divisorPressed: Bool = false
    
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func numberButton(_ sender: UIButton) {
        displayText = displayText + String(sender.tag)
        displayLabel.text = displayText
    }
    
    @IBAction func arithmeticButton(_ sender: UIButton) {
        if sender.tag == 11 {
            pointCounter += 1
            if pointCounter < 2 {
                displayText += "."
            }
            displayLabel.text = displayText
        }
        
        if sender.tag == 102 {
            if plusPressed == false {
                preNumber = Double(displayText)!
                pointCounter = 0
                displayLabel.text = displayText + "+"
                displayText = ""
                plusPressed = true
            }
        } else if sender.tag == 103 {
            if minusPressed == false {
                preNumber = Double(displayText)!
                pointCounter = 0
                displayLabel.text = displayText + "-"
                displayText = ""
                minusPressed = true
            }
        } else if sender.tag == 104 {
            if multiplierPressed == false {
                preNumber = Double(displayText)!
                pointCounter = 0
                displayLabel.text = displayText + "x"
                displayText = ""
                multiplierPressed = true
            }
        } else if sender.tag == 105  {
            if divisorPressed == false {
                preNumber = Double(displayText)!
                pointCounter = 0
                displayLabel.text = displayText + "/"
                displayText = ""
                divisorPressed = true
            }
        } else if sender.tag == 101 {
            postNumber = Double(displayText)!
            if plusPressed == true {
                result = preNumber + postNumber
                displayLabel.text = String(result)
            } else if minusPressed == true {
                result = preNumber - postNumber
                displayLabel.text = String(result)
            } else if multiplierPressed == true {
                result = preNumber * postNumber
                displayLabel.text = String(result)
            } else if divisorPressed == true {
                result = preNumber / postNumber
                displayLabel.text = String(result)
            }
        } else if sender.tag == 999 {
            displayText = "0"
            displayLabel.text = displayText
            pointCounter = 0
            plusPressed = false
            minusPressed = false
            multiplierPressed = false
            divisorPressed = false
        }
    }
    
    
}


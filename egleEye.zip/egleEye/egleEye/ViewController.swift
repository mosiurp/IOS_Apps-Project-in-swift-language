//
//  ViewController.swift
//  egleEye
//
//  Created by macOS High Sierra on 9/5/18.
//  Copyright © 2018 Next Tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var targetLabel: UILabel!
    @IBOutlet weak var roundLabel: UILabel!
    
    var points = 0
    var score = 0
    var round = 0
    var targetValue = 1 + Int(arc4random_uniform(100))
    var currentValue = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let thumbImageNormal = UIImage(named: "SliderThumb-Normal")
        slider.setThumbImage(thumbImageNormal, for: .normal)
        
        slider.setThumbImage(#imageLiteral(resourceName: "SliderThumb-Highlighted"), for: .highlighted)
        
        let insets = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        
        let minimumTrackImage = #imageLiteral(resourceName: "SliderTrackLeft")
        let minimumTrackImageResized = minimumTrackImage.resizableImage(withCapInsets: insets)
        slider.setMinimumTrackImage(minimumTrackImageResized, for: .normal)
        
        let maximumTrackImage = #imageLiteral(resourceName: "SliderTrackRight")
        let maximumTrackImageResized = maximumTrackImage.resizableImage(withCapInsets: insets)
        slider.setMaximumTrackImage(maximumTrackImageResized, for: .normal)
        
        targetLabel.text = "Put the EgleEye as close as you can to: \(targetValue)"
    }
    
    @IBAction func hitButton (_ sender: Any) {
        showAlert()
    }

    @IBAction func sliderMoved(_ sender: UISlider) {
        currentValue = lroundf(sender.value)
    }
    
    func showAlert() {
        var alertTitle = ""
        var message = "Your value of slider is now: \(currentValue)"
        let difference = abs(targetValue - currentValue)
        
        if difference == 0 {
            alertTitle = "Perfect"
            score = 100
        } else if difference < 5 {
            alertTitle = "So Close"
            if difference > 0 {
                score = 50
            }
        } else if difference < 10 {
            alertTitle = "Pretty Good"
            if difference > 5 {
                score = 25
            }
        } else {
            alertTitle = "Not even Close"
        }
        
        points += score
        
        message += "\nYour Scored: \(score)"
        
        let alert = UIAlertController(title: alertTitle, message: message, preferredStyle: .alert)
        
        let action = UIAlertAction(title: "OK", style: .default) { (UIAlertAction) in
            self.startNewRound()
        }
        
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    func startNewRound () {
        round += 1
        targetValue = 1 + Int(arc4random_uniform(100))
        currentValue = 50
        slider.value = Float(currentValue)
        UIUpdate()
    }
    
    func UIUpdate () {
        targetLabel.text = "Put the EgleEye as close as you can to: \(targetValue)"
        roundLabel.text = "Round: \(round)"
        scoreLabel.text = "Score: \(points)"
    }

}

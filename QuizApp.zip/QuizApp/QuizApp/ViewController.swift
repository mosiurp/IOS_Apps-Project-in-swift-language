//
//  ViewController.swift
//  QuizApp
//
//  Created by Tasauf Mim on 2/8/18.
//  Copyright © 2018 Tasauf Mim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let allQuestions = QuestionBank()
    var pickedAnswer: Bool = false
    var questionNumber: Int = 0
    var score = 0

    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var progressLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var progressBar: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nextQuestion()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func answerButtonPressed(_ sender: Any) {
        if (sender as AnyObject).tag == 1 {
            pickedAnswer = true
        } else if (sender as AnyObject).tag == 2 {
            pickedAnswer = false
        }
        
        checkAnswer()
        
        questionNumber += 1
        
        nextQuestion()
        
        
        
    }
    
    func checkAnswer () {
        let correctAnswer = allQuestions.list[questionNumber].answer
        
        if correctAnswer == pickedAnswer {
            ProgressHUD.showSuccess("Answer is correct")
            print("You Got it")
            score += 1
        } else {
            ProgressHUD.showError("Answer is Wrong")
            print("Wrong")
        }
    }
    
    func nextQuestion () {
        if questionNumber < 13 {
            questionLabel.text = allQuestions.list[questionNumber].questionText
            UIUpdate()
        } else {
            let alert = UIAlertController(title: "Awesome", message: "You have finished all of question, do you want to start over?", preferredStyle: .alert)
            
            let restartAction = UIAlertAction(title: "Restart", style: .default, handler: { (UIAlertAction) in
                self.startOver()
            })
            
            alert.addAction(restartAction)
            
            present(alert, animated: true, completion: nil)
        }
    }
    
    func startOver() {
        questionNumber = 0
        nextQuestion()
        score = 0
    }
    
    func UIUpdate () {
        scoreLabel.text = "Score: \(score)"
        progressLabel.text = "\(questionNumber + 1)/13"
        progressBar.frame.size.width = (view.frame.size.width / 13) * CGFloat(questionNumber + 1)
    }

}


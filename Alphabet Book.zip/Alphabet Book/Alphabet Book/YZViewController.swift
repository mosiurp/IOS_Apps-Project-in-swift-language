//
//  YZViewController.swift
//  Alphabet Book
//
//  Created by Tasauf Mim on 25/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit
import AVFoundation

class YZViewController: UIViewController {
    
    var soundFileName = ""
    
    var audioPlayer: AVAudioPlayer!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func alphaButton(_ sender: UIButton) {
        if sender.tag == 0 {
            soundFileName = "Y for Yoyo"
        } else {
            soundFileName = "Z for Zebra"
        }
        
        let soundURL = Bundle.main.url(forResource: soundFileName, withExtension: "MP3")
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL!)
        } catch {
            print(error)
        }
        audioPlayer.play()
    }
    
}

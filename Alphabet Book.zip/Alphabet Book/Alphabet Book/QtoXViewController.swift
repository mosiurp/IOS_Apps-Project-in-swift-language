//
//  QtoXViewController.swift
//  Alphabet Book
//
//  Created by Tasauf Mim on 25/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit
import AVFoundation

class QtoXViewController: UIViewController {
    
    var soundFileName = ""
    
    var audioPlayer: AVAudioPlayer!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func alphaButton(_ sender: UIButton) {
        if sender.tag == 0 {
            soundFileName = "Q for Queen"
        } else if sender.tag == 1 {
            soundFileName = "R for Rabbit"
        } else if sender.tag == 2 {
            soundFileName = "S for Snake"
        } else if sender.tag == 3 {
            soundFileName = "T for Tiger"
        } else if sender.tag == 4 {
            soundFileName = "U for Umbrella"
        } else if sender.tag == 5 {
            soundFileName = "V for Van"
        } else if sender.tag == 6 {
            soundFileName = "W for Watch"
        } else {
            soundFileName = "X for Xmas"
        }
        
        let soundURL = Bundle.main.url(forResource: soundFileName, withExtension: "MP3")
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL!)
        } catch {
            print(error)
        }
        audioPlayer.play()
    }
    
}

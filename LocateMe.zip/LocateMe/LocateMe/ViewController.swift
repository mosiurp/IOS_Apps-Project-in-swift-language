//
//  ViewController.swift
//  LocateMe
//
//  Created by Tasauf Mim on 25/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {
    
    let gpsManager = CLLocationManager()
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let userLocation = locations[locations.count - 1]
        
        let coordinates: CLLocationCoordinate2D = CLLocationCoordinate2DMake(userLocation.coordinate.latitude, userLocation.coordinate.longitude)
        let view: MKCoordinateSpan = MKCoordinateSpanMake(0.01, 0.01)
        let region: MKCoordinateRegion = MKCoordinateRegionMake(coordinates, view)
        
        map.setRegion(region, animated: true)
        map.showsUserLocation = true
        
    }
    
    @IBOutlet weak var map: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        gpsManager.delegate = self
        gpsManager.desiredAccuracy = kCLLocationAccuracyBest
        gpsManager.requestWhenInUseAuthorization()
        gpsManager.startUpdatingLocation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
}




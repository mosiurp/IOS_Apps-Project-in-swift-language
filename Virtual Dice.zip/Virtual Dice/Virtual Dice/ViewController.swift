//
//  ViewController.swift
//  Virtual Dice
//
//  Created by Tasauf Mim on 24/9/18.
//  Copyright © 2018 Abstract Lab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var randomDiceIndex: UInt32 = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func diceButtonTapped(_ sender: UIButton) {
        if sender.tag == 0 {
            randomDiceIndex = arc4random_uniform(6) + 1
            sender.setBackgroundImage(UIImage(named: "dice\(randomDiceIndex)"), for: .normal)
        } else if sender.tag == 1 {
            randomDiceIndex = arc4random_uniform(6) + 1
            sender.setBackgroundImage(UIImage(named: "dice\(randomDiceIndex)"), for: .normal)
        } else if sender.tag == 2 {
            randomDiceIndex = arc4random_uniform(6) + 1
            sender.setBackgroundImage(UIImage(named: "dice\(randomDiceIndex)"), for: .normal)
        } else {
            randomDiceIndex = arc4random_uniform(6) + 1
            sender.setBackgroundImage(UIImage(named: "dice\(randomDiceIndex)"), for: .normal)
        }
    }
    


}
